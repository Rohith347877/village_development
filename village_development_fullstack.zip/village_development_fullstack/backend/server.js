
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// In-memory storage for demo purposes
let users = [];
let complaints = [];

// Multer for image uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Registration endpoint
app.post('/register', (req, res) => {
  const { aadhaar, fullname, dob, age, role, district, mandal, village } = req.body;
  const userExists = users.find(u => u.aadhaar === aadhaar);
  if (userExists) return res.status(400).send({ message: 'User already exists' });
  users.push({ aadhaar, fullname, dob, age, role, district, mandal, village });
  res.status(201).send({ message: 'User registered successfully' });
});

// Login endpoint
app.post('/login', (req, res) => {
  const { aadhaar } = req.body;
  const user = users.find(u => u.aadhaar === aadhaar);
  if (!user) return res.status(404).send({ message: 'User not found' });
  res.send({ message: 'Login successful', user });
});

// Submit complaint
app.post('/complaint', upload.array('images', 3), (req, res) => {
  const { aadhaar, issueType, description } = req.body;
  const images = req.files.map(file => file.filename);
  complaints.push({ aadhaar, issueType, description, images });
  res.status(201).send({ message: 'Complaint submitted' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
